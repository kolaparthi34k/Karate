package org.cap.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day2SpringBootMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day2SpringBootMvcApplication.class, args);
	}
}
