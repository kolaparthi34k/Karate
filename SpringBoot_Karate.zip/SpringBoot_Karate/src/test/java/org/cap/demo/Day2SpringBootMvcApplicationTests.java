package org.cap.demo;


import org.junit.runner.RunWith;
import com.intuit.karate.junit4.Karate;

@RunWith(Karate.class)
public class Day2SpringBootMvcApplicationTests {

}
